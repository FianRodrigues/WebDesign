import './styles.scss';
const todoJson = 'http://localhost:3000/todoJson'

getTodos();


// Basically the code is exactly the same for both 
// the browser and node.js versions. The only difference 
// is that the browser uses XmlHttpRequest whilst node.js 
// uses http module.

//  a method to display the todo tasks for the ui
function showTodo(title, description, date, time, complete) {

    //Adding new tasks the to the todo list in the table
    var todoList = document.getElementById("todo-section");
    todoList.innerHTML += ' <tr id="tblRow"><td>' + title + '</td> <td>' +
                             description + '</td> <td>' + date + '</td> <td>' + 
                             time + '</td> <td> <input type="checkbox" class="tick" onclick="compTodo(event)"> </td>  <td > <button type="button" class="del button" onclick="compTodo(event)"> Delete </button> </td>  </tr>';
                             }

window.compTodo = function (event) {

    var a = event
    const item = a.target;

    if (item.classList[0] === "del") {
        const tod = item.closest("#tblRow");
        tod.remove();
    }

    if (item.classList[0] === "tick") {
        const tod = item.closest("#tblRow");
        tod.classList.toggle("completed")
    }

}

// This section of the code is to take in the values of the title, 
// description, date and time of the task added
window.addTodo = function () {

    var titleInput = document.getElementById("todo-input").value;
    var descInput = document.getElementById("todo-description").value;
    var dateInput = document.getElementById("todo-date").value;
    var timeInput = document.getElementById("todo-time").value;
    var complete = false;

    if (titleInput.length > 0) {
        showTodo(titleInput, descInput, dateInput, timeInput, complete);
    }

}



// this code block is to fetch the GET method
// using the  node modules to take it in and 
// usig webpack and xhr in tandem to get it out to the webpage
function getTodos() {
    fetch(todoJson, {
        method: 'GET'
    }).then(response => { return response.json() })
        .then(data => {
            var todoList = data;
            console.log("data", data)
            for (var i in todoList) {
                showTodo(todoList[i]["title"], todoList[i]["description"], todoList[i]["date"], todoList[i]["time"], todoList[i]["complete"]);
            }
        })
        .catch(error => console.error(error))
}

